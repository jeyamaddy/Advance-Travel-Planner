function carbonapi() {
    const car = document.getElementById("car").value;
    const distance = parseFloat(document.getElementById("dist").value);
    const unit = document.getElementById("unit").value;
    const resultElement = document.getElementById("result");

    // Check if the distance input is valid
    if (isNaN(distance) || distance <= 0) {
        resultElement.textContent = "Please enter a valid distance.";
        return;
    }

    // Average CO2 emissions per km (in grams)
    const emissionsPerKm = {
        "Car-Size-Small": 120,   // Small car: 120g CO2/km
        "Car-Size-Medium": 150,  // Medium car: 150g CO2/km
        "Car-Size-Large": 200    // Large car: 200g CO2/km
    };

    // Calculate the carbon emissions in grams
    const emissions = emissionsPerKm[car] * distance;

    // Convert emissions based on the selected unit
    let convertedEmissions;
    switch (unit) {
        case "kg":
            convertedEmissions = emissions / 1000; // Convert to kilograms
            break;
        case "mt":
            convertedEmissions = emissions / 1e6;  // Convert to metric tonnes
            break;
        case "lb":
            convertedEmissions = emissions * 0.00220462; // Convert to pounds
            break;
        case "g":
        default:
            convertedEmissions = emissions; // Keep in grams
    }

    // Display the result
    resultElement.textContent = `Estimated Carbon Emission: ${convertedEmissions.toFixed(2)} ${unit}`;
}
